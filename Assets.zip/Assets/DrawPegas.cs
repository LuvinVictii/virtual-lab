using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class PegasZigZag : MonoBehaviour
{
    public Transform anchor;     // Titik atas (pegas nempel)
    public Transform beban;      // Titik bawah (beban menggantung)
    public int zigzagCount = 10; // Jumlah gelombang zigzag
    public float zigzagAmplitude = 0.1f; // Jarak kiri-kanan tiap zigzag
    public float lineWidth = 0.2f;

    private LineRenderer lr;

    void Start()
    {
        lr = GetComponent<LineRenderer>();
        lr.startWidth = lineWidth;
        lr.endWidth = lineWidth;
    }

    void Update()
    {
        DrawPegas(anchor.position, beban.position);
    }

    void DrawPegas(Vector2 start, Vector2 end)
    {
        lr.positionCount = zigzagCount + 2; // 2 titik ujung + zigzag

        Vector2 dir = (end - start).normalized;
        float length = Vector2.Distance(start, end);
        Vector2 perp = new Vector2(-dir.y, dir.x); // arah zigzag (tegak lurus pegas)

        lr.SetPosition(0, start);
        for (int i = 1; i <= zigzagCount; i++)
        {
            float t = (float)i / (zigzagCount + 1);
            Vector2 point = Vector2.Lerp(start, end, t);
            float offset = ((i % 2 == 0) ? 1 : -1) * zigzagAmplitude;
            point += perp * offset;
            lr.SetPosition(i, point);
        }
        lr.SetPosition(zigzagCount + 1, end);
    }
}
